Anggota :
Rivo Juicer Wowor (00000059635)
Felix Rafael (00000060086)
Auliyaa Vishwakarma Hestia (00000059515)
Fadhil Dzaky Muhammad (00000058398)