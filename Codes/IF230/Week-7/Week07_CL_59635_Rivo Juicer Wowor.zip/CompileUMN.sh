#!/bin/bash

echo "Compiling..."
mkdir win-bin
make windows
